import { kbnUrlDirective } from './kbnHref';

kbnUrlDirective('kbnSrc');
