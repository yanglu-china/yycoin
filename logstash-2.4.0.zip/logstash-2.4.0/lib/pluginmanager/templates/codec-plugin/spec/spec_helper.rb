# encoding: utf-8
require "logstash/devutils/rspec/spec_helper"
